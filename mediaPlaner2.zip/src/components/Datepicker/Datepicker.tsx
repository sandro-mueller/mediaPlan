export const Datepicker = () => {
  return <div></div>;
};
