export { LOTTIE_OPTIONS } from './lottie/index';
