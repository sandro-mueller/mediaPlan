export const mediaPlan = {
  page: 0,
  title: '',
  type: '',
  startDate: '',
  endDate: '',
  isTitle: false,
  isStartDate: false,
  isEndDate: false,
  isDateError: false,

  currentOption: 'SEA',

  mode: 'light',
};
