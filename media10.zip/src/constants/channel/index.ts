import { ChannelOptions } from '@type/index';

export const CHANNEL_OPTIONS: ChannelOptions = [
  'SEA',
  'Display',
  'Social',
  'Affiliate',
  'Remarketing',
];
