import styled from '@emotion/styled';
import facepaint from 'facepaint';
import { FormChannel } from '@components/Form/FormChannel';
import { FormGeneral } from '@components/Form/FormGeneral';
import { State } from '@store/interface';
import { FormGeneralCta } from '@components/Form/FormGeneralCta';
import { FormChannelCta } from '@components/Form/FormChannelCta';
import { useSelector } from 'react-redux';

const breakPoints = [1000, 1200];
const mediaQuery = facepaint(
  breakPoints.map((breakpoint) => `@media (min-width: ${breakpoint}px)`)
);

const StyledContainerForm = styled.div(mediaQuery({ width: ['100%', '50%'] }));

export const ContainerForm = (): JSX.Element => {
  const { page } = useSelector((state: State) => state.mediaPlan);

  if (!page) {
    return (
      <StyledContainerForm>
        <FormGeneral />
        <FormGeneralCta />
      </StyledContainerForm>
    );
  }

  return (
    <StyledContainerForm>
      <FormChannel />
      <FormChannelCta />
    </StyledContainerForm>
  );
};
