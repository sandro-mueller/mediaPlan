export const mediaPlan = {
  page: '',
  title: '',
  type: '',
  startDate: '',
  endDate: '',
  isTitle: false,
  isStartDate: false,
  isEndDate: false,
  isDateError: false,

  currentOption: 'SEA',
};
