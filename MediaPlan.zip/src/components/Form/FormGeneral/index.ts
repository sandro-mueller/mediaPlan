export { FormGeneral } from './FormGeneral';

// HEADER
export { FormGeneralBasis } from './Header';

// FOOTER
export { FormGeneralCta } from './Footer';
