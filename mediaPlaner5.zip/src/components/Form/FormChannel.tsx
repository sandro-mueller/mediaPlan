interface Props {
  handlePage: () => void;
}

export const FormChannel = ({ handlePage }: Props) => {
  return <div>FormChannel</div>;
};
