import React from 'react';
import styled from '@emotion/styled';
import facepaint from 'facepaint';
import { FormChannel } from '@components/Form/FormChannel';
import { FormGeneral } from '@components/Form/FormGeneral';

const breakPoints = [1000, 1200];

const mediaQuery = facepaint(
  breakPoints.map((breakpoint) => `@media (min-width: ${breakpoint}px)`)
);

const StyledContainerForm = styled.div(
  mediaQuery({ width: ['100%', '50%'] }),

  () => ({})
);

export const ContainerForm = () => {
  const [page, setPage] = React.useState(0);

  const onHandlePage = () => {
    setPage((prev) => prev + 1);
  };

  return (
    <StyledContainerForm>
      {!page && <FormGeneral handlePage={onHandlePage} />}
      {!!page && <FormChannel handlePage={onHandlePage} />}
    </StyledContainerForm>
  );
};
