export { ToastComponent } from './Toast';
